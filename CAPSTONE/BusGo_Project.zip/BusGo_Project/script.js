var L={
en:{tag:"Bus Reservation and Ticketing System",mobile:"Mobile",email:"Email",admin:"Admin",mobLbl:"Mobile number",emailLbl:"Email address",sendOtp:"Send OTP",resend:"Resend OTP",otpLbl:"Enter OTP",verify:"Verify and login",user:"Admin username",pass:"Password",login:"Login",demoOtp:"Demo OTP (no SMS or email server):",book:"Book bus tickets",from:"From",to:"To",date:"Travel date",search:"Search buses",hint:"Select From, To and date, then press Search buses.",viewSeats:"View seats",left:"seats left",hrs:"hrs journey",buses:"buses",back:"← Back",select:"Select seats (max 6)",driver:"Driver",pd:"Passenger details",name:"Name",age:"Age",male:"Male",female:"Female",seatN:"seat(s)",proceed:"Proceed to payment",free:"Free",selM:"Selected male",selF:"Selected female",bkM:"Booked male",bkF:"Booked female",seatHint:"Click a seat. Male shows blue, female shows pink.",payOpt:"Payment options",summary:"Booking summary",total:"Total",pay:"Pay",proc:"Processing payment...",demoPay:"Demo payment. No real money is charged.",ticket:"BUS TICKET",route:"Route",dep:"Departure",bus:"Bus",type:"Type",payL:"Payment",amount:"Amount paid",pass2:"Passengers",ok:"Payment successful. Ticket booked!",another:"Book another ticket",nsearch:"Search buses",mine:"My bookings",dash:"Dashboard",logout:"Logout",active:"Total bookings",sold:"Seats sold",rev:"Revenue",filter:"Search bookings (ticket, mobile/email, name)",by:"Booked by",rb:"Route / Bus",td:"Travel date",pm:"Payment",empty:"No bookings yet.",
eMob:"Enter a valid 10-digit mobile number (starts with 6-9).",eEmail:"Enter a valid email address.",sent:"OTP sent to",eOtp:"Wrong OTP. Try again.",eAdmin:"Wrong admin username or password.",eSame:"From and To cannot be the same.",eDate:"Select a travel date.",eMax:"Maximum 6 seats per booking.",eNone:"Select at least one seat.",eName:"Enter passenger name for seat",eAge:"Enter a valid age (1-120) for seat",ePay:"Invalid payment details:",eTaken:"Seat already booked by someone else:"},
ta:{tag:"பேருந்து முன்பதிவு மற்றும் டிக்கெட் அமைப்பு",mobile:"மொபைல்",email:"மின்னஞ்சல்",admin:"நிர்வாகி",mobLbl:"மொபைல் எண்",emailLbl:"மின்னஞ்சல் முகவரி",sendOtp:"OTP அனுப்பு",resend:"மீண்டும் அனுப்பு",otpLbl:"OTP உள்ளிடவும்",verify:"சரிபார்த்து உள்நுழை",user:"நிர்வாகி பயனர்பெயர்",pass:"கடவுச்சொல்",login:"உள்நுழை",demoOtp:"டெமோ OTP (SMS/மின்னஞ்சல் சேவையகம் இல்லை):",book:"பேருந்து டிக்கெட் முன்பதிவு",from:"புறப்படும் இடம்",to:"சேருமிடம்",date:"பயண தேதி",search:"பேருந்துகளைத் தேடு",hint:"புறப்படும் இடம், சேருமிடம், தேதியைத் தேர்ந்தெடுத்து தேடவும்.",viewSeats:"இருக்கைகளைப் பார்",left:"இருக்கைகள் மீதம்",hrs:"மணி பயணம்",buses:"பேருந்துகள்",back:"← பின்செல்",select:"இருக்கைகளைத் தேர்ந்தெடுக்கவும் (அதிகபட்சம் 6)",driver:"ஓட்டுநர்",pd:"பயணி விவரங்கள்",name:"பெயர்",age:"வயது",male:"ஆண்",female:"பெண்",seatN:"இருக்கை(கள்)",proceed:"பணம் செலுத்தத் தொடரவும்",free:"காலி",selM:"தேர்வு (ஆண்)",selF:"தேர்வு (பெண்)",bkM:"பதிவு (ஆண்)",bkF:"பதிவு (பெண்)",seatHint:"இருக்கையைத் தேர்ந்தெடுக்கவும். ஆண் நீலம், பெண் இளஞ்சிவப்பு நிறத்தில் தெரியும்.",payOpt:"பணம் செலுத்தும் முறை",summary:"முன்பதிவு சுருக்கம்",total:"மொத்தம்",pay:"செலுத்து",proc:"செயலாக்கம்...",demoPay:"இது டெமோ கட்டணம். உண்மையான பணம் எடுக்கப்படாது.",ticket:"பேருந்து டிக்கெட்",route:"வழி",dep:"புறப்பாடு",bus:"பேருந்து",type:"வகை",payL:"கட்டணம்",amount:"செலுத்திய தொகை",pass2:"பயணிகள்",ok:"கட்டணம் வெற்றி. டிக்கெட் பதிவானது!",another:"மற்றொரு டிக்கெட் பதிவு செய்",nsearch:"பேருந்து தேடல்",mine:"என் முன்பதிவுகள்",dash:"டாஷ்போர்டு",logout:"வெளியேறு",active:"மொத்த முன்பதிவுகள்",sold:"விற்ற இருக்கைகள்",rev:"வருவாய்",filter:"முன்பதிவு தேடு (டிக்கெட், மொபைல்/மின்னஞ்சல், பெயர்)",by:"பதிவு செய்தவர்",rb:"வழி / பேருந்து",td:"பயண தேதி",pm:"கட்டணம்",empty:"இன்னும் முன்பதிவு இல்லை.",
eMob:"சரியான 10 இலக்க மொபைல் எண்ணை உள்ளிடவும் (6-9 இல் தொடங்க வேண்டும்).",eEmail:"சரியான மின்னஞ்சல் முகவரியை உள்ளிடவும்.",sent:"OTP அனுப்பப்பட்டது:",eOtp:"தவறான OTP. மீண்டும் முயற்சிக்கவும்.",eAdmin:"நிர்வாகி பயனர்பெயர் அல்லது கடவுச்சொல் தவறு.",eSame:"புறப்படும் இடமும் சேருமிடமும் ஒன்றாக இருக்கக்கூடாது.",eDate:"பயண தேதியைத் தேர்ந்தெடுக்கவும்.",eMax:"ஒரு முன்பதிவுக்கு அதிகபட்சம் 6 இருக்கைகள்.",eNone:"குறைந்தது ஒரு இருக்கையைத் தேர்ந்தெடுக்கவும்.",eName:"பயணி பெயரை உள்ளிடவும், இருக்கை",eAge:"சரியான வயதை (1-120) உள்ளிடவும், இருக்கை",ePay:"கட்டண விவரம் தவறு:",eTaken:"இந்த இருக்கை ஏற்கனவே பதிவாகிவிட்டது:"},
hi:{tag:"बस आरक्षण और टिकट प्रणाली",mobile:"मोबाइल",email:"ईमेल",admin:"एडमिन",mobLbl:"मोबाइल नंबर",emailLbl:"ईमेल पता",sendOtp:"OTP भेजें",resend:"फिर से भेजें",otpLbl:"OTP दर्ज करें",verify:"सत्यापित करें और लॉगिन करें",user:"एडमिन यूज़रनेम",pass:"पासवर्ड",login:"लॉगिन",demoOtp:"डेमो OTP (SMS/ईमेल सर्वर नहीं है):",book:"बस टिकट बुक करें",from:"कहाँ से",to:"कहाँ तक",date:"यात्रा की तारीख",search:"बसें खोजें",hint:"कहाँ से, कहाँ तक और तारीख चुनकर खोजें।",viewSeats:"सीटें देखें",left:"सीटें बाकी",hrs:"घंटे की यात्रा",buses:"बसें",back:"← वापस",select:"सीटें चुनें (अधिकतम 6)",driver:"ड्राइवर",pd:"यात्री विवरण",name:"नाम",age:"उम्र",male:"पुरुष",female:"महिला",seatN:"सीट",proceed:"भुगतान के लिए आगे बढ़ें",free:"खाली",selM:"चयनित (पुरुष)",selF:"चयनित (महिला)",bkM:"बुक (पुरुष)",bkF:"बुक (महिला)",seatHint:"सीट चुनें। पुरुष नीला, महिला गुलाबी रंग में दिखेगा।",payOpt:"भुगतान विकल्प",summary:"बुकिंग सारांश",total:"कुल",pay:"भुगतान करें",proc:"प्रक्रिया जारी...",demoPay:"यह डेमो भुगतान है। असली पैसा नहीं कटेगा।",ticket:"बस टिकट",route:"मार्ग",dep:"प्रस्थान",bus:"बस",type:"प्रकार",payL:"भुगतान",amount:"भुगतान राशि",pass2:"यात्री",ok:"भुगतान सफल। टिकट बुक हो गया!",another:"एक और टिकट बुक करें",nsearch:"बस खोज",mine:"मेरी बुकिंग",dash:"डैशबोर्ड",logout:"लॉगआउट",active:"कुल बुकिंग",sold:"बिकी सीटें",rev:"आय",filter:"बुकिंग खोजें (टिकट, मोबाइल/ईमेल, नाम)",by:"बुक करने वाला",rb:"मार्ग / बस",td:"यात्रा तिथि",pm:"भुगतान",empty:"अभी तक कोई बुकिंग नहीं।",
eMob:"सही 10 अंकों का मोबाइल नंबर दर्ज करें (6-9 से शुरू)।",eEmail:"सही ईमेल पता दर्ज करें।",sent:"OTP भेजा गया:",eOtp:"गलत OTP। फिर से प्रयास करें।",eAdmin:"एडमिन यूज़रनेम या पासवर्ड गलत है।",eSame:"कहाँ से और कहाँ तक एक जैसे नहीं हो सकते।",eDate:"यात्रा की तारीख चुनें।",eMax:"एक बुकिंग में अधिकतम 6 सीटें।",eNone:"कम से कम एक सीट चुनें।",eName:"यात्री का नाम दर्ज करें, सीट",eAge:"सही उम्र (1-120) दर्ज करें, सीट",ePay:"भुगतान विवरण गलत:",eTaken:"यह सीट पहले ही बुक हो चुकी है:"}};
Object.assign(L.en,{profile:"Profile",profileHint:"Complete your profile to continue booking.",fullName:"Full name",dob:"Date of birth",ageL:"Age",gender:"Gender",other:"Other",mobileNo:"Mobile number",emailAd:"Email address",city:"City",saveP:"Save profile",saved:"Profile saved.",eProfName:"Enter your full name (min 2 letters).",eDob:"Enter a valid date of birth.",eGender:"Select gender.",
cancelTkt:"Cancel ticket",cancelled:"Cancelled",refund:"Refund",refundNote:"Refund (90% of fare):",verifyCx:"For security, enter the OTP sent to your registered mobile or email.",verifyCxA:"Enter the admin password to confirm cancellation.",confirmCx:"Confirm cancel",keep:"Keep ticket",eVerify:"Verification failed. Try again.",
track:"Track bus",trackTitle:"Live tracking",simulate:"Start demo simulation",openMaps:"Open in Google Maps",gmFail:"Google Map cannot load inside this preview. Use the Open in Google Maps button.",status:"Status",notStarted:"Not started yet",inTransit:"In transit",arrived:"Arrived",covered:"Covered",remaining:"Remaining",speed:"Speed",eta:"Arrival",distance:"Distance",simOn:"Demo simulation running",confirmed:"Confirmed"});
Object.assign(L.ta,{profile:"சுயவிவரம்",profileHint:"தொடர்ந்து முன்பதிவு செய்ய சுயவிவரத்தை நிரப்பவும்.",fullName:"முழு பெயர்",dob:"பிறந்த தேதி",ageL:"வயது",gender:"பாலினம்",other:"மற்றவை",mobileNo:"மொபைல் எண்",emailAd:"மின்னஞ்சல்",city:"நகரம்",saveP:"சுயவிவரத்தைச் சேமி",saved:"சுயவிவரம் சேமிக்கப்பட்டது.",eProfName:"முழு பெயரை உள்ளிடவும்.",eDob:"சரியான பிறந்த தேதியை உள்ளிடவும்.",eGender:"பாலினத்தைத் தேர்ந்தெடுக்கவும்.",
cancelTkt:"டிக்கெட் ரத்து",cancelled:"ரத்து செய்யப்பட்டது",refund:"திரும்பப் பெறும் தொகை",refundNote:"திரும்பப் பெறும் தொகை (கட்டணத்தில் 90%):",verifyCx:"பாதுகாப்புக்காக, உங்கள் மொபைல்/மின்னஞ்சலுக்கு அனுப்பிய OTP-ஐ உள்ளிடவும்.",verifyCxA:"ரத்து செய்ய நிர்வாகி கடவுச்சொல்லை உள்ளிடவும்.",confirmCx:"ரத்து உறுதி",keep:"டிக்கெட்டை வைத்திரு",eVerify:"சரிபார்ப்பு தோல்வி. மீண்டும் முயற்சிக்கவும்.",
track:"பேருந்தைக் கண்காணி",trackTitle:"நேரடி கண்காணிப்பு",simulate:"டெமோ தொடங்கு",openMaps:"Google Maps-ல் திற",gmFail:"இந்த முன்னோட்டத்தில் Google Map ஏற்றப்படாது. Google Maps-ல் திற பொத்தானை அழுத்தவும்.",status:"நிலை",notStarted:"இன்னும் தொடங்கவில்லை",inTransit:"பயணத்தில்",arrived:"வந்து சேர்ந்தது",covered:"கடந்த தூரம்",remaining:"மீதம்",speed:"வேகம்",eta:"சேரும் நேரம்",distance:"தூரம்",simOn:"டெமோ ஓடுகிறது",confirmed:"உறுதி"});
Object.assign(L.hi,{profile:"प्रोफ़ाइल",profileHint:"बुकिंग जारी रखने के लिए प्रोफ़ाइल पूरी करें।",fullName:"पूरा नाम",dob:"जन्म तिथि",ageL:"उम्र",gender:"लिंग",other:"अन्य",mobileNo:"मोबाइल नंबर",emailAd:"ईमेल",city:"शहर",saveP:"प्रोफ़ाइल सहेजें",saved:"प्रोफ़ाइल सहेजी गई।",eProfName:"अपना पूरा नाम दर्ज करें।",eDob:"सही जन्म तिथि दर्ज करें।",eGender:"लिंग चुनें।",
cancelTkt:"टिकट रद्द करें",cancelled:"रद्द",refund:"रिफंड",refundNote:"रिफंड (किराये का 90%):",verifyCx:"सुरक्षा के लिए, अपने मोबाइल/ईमेल पर भेजा गया OTP दर्ज करें।",verifyCxA:"रद्द करने के लिए एडमिन पासवर्ड दर्ज करें।",confirmCx:"रद्द करना पक्का करें",keep:"टिकट रखें",eVerify:"सत्यापन विफल। फिर से प्रयास करें।",
track:"बस ट्रैक करें",trackTitle:"लाइव ट्रैकिंग",simulate:"डेमो शुरू करें",openMaps:"Google Maps में खोलें",gmFail:"इस प्रीव्यू में Google Map लोड नहीं होगा। Google Maps में खोलें बटन दबाएँ।",status:"स्थिति",notStarted:"अभी शुरू नहीं हुई",inTransit:"रास्ते में",arrived:"पहुँच गई",covered:"तय दूरी",remaining:"बाकी",speed:"गति",eta:"पहुँचने का समय",distance:"दूरी",simOn:"डेमो चल रहा है",confirmed:"पक्का"});
var TM,GMT=0;
Object.assign(L.en,{bookId:"Booking ID",tkTitle:"Bus Ticket / Reservation",operator:"Operator",seatNo:"Seat No.",reach:"Please reach the boarding point 15 mins before departure.",baseFare:"Base fare",conv:"Convenience fee",taxInv:"Tax invoice (GST)",invNo:"Invoice No",sample:"Sample invoice for a college project. Not a legal tax document.",sort:"Sort by",sortDep:"Departure time",sortPrice:"Price: low to high",sortDur:"Fastest",allTypes:"All bus types",perSeat:"per seat",plusTax:"+ GST and fees added at payment",printT:"Print / Save PDF",happy:"Happy journey!",fareDet:"Fare details",refundNote:"Refund (90% of fare and GST; convenience fee is not refunded):"});
Object.assign(L.ta,{bookId:"முன்பதிவு எண்",tkTitle:"பேருந்து டிக்கெட் / முன்பதிவு",operator:"இயக்குநர்",seatNo:"இருக்கை எண்",reach:"புறப்படுவதற்கு 15 நிமிடம் முன் ஏறும் இடத்திற்கு வரவும்.",baseFare:"அடிப்படைக் கட்டணம்",conv:"வசதிக் கட்டணம்",taxInv:"வரி விலைப்பட்டியல் (GST)",invNo:"விலைப்பட்டியல் எண்",sample:"கல்லூரி திட்டத்திற்கான மாதிரி விலைப்பட்டியல். சட்டப்பூர்வ வரி ஆவணம் அல்ல.",sort:"வரிசைப்படுத்து",sortDep:"புறப்படும் நேரம்",sortPrice:"விலை: குறைவு முதல்",sortDur:"வேகமானது",allTypes:"அனைத்து வகை",perSeat:"ஒரு இருக்கைக்கு",plusTax:"+ GST மற்றும் கட்டணங்கள் பணம் செலுத்தும்போது சேரும்",printT:"அச்சிடு / PDF",happy:"இனிய பயணம்!",fareDet:"கட்டண விவரம்"});
Object.assign(L.hi,{bookId:"बुकिंग आईडी",tkTitle:"बस टिकट / आरक्षण",operator:"ऑपरेटर",seatNo:"सीट नंबर",reach:"कृपया प्रस्थान से 15 मिनट पहले बोर्डिंग पॉइंट पर पहुँचें।",baseFare:"मूल किराया",conv:"सुविधा शुल्क",taxInv:"कर चालान (GST)",invNo:"चालान नंबर",sample:"कॉलेज प्रोजेक्ट के लिए नमूना चालान। यह वैध कर दस्तावेज़ नहीं है।",sort:"क्रमबद्ध करें",sortDep:"प्रस्थान समय",sortPrice:"कीमत: कम से ज़्यादा",sortDur:"सबसे तेज़",allTypes:"सभी प्रकार",perSeat:"प्रति सीट",plusTax:"+ GST और शुल्क भुगतान पर जुड़ेंगे",printT:"प्रिंट / PDF",happy:"शुभ यात्रा!",fareDet:"किराया विवरण"});
var STAND={Chennai:"Koyambedu Bus Stand",Bangalore:"Majestic Bus Station",Hyderabad:"MGBS Bus Station",Mumbai:"Dadar Bus Stop",Kochi:"Vyttila Mobility Hub",Madurai:"Periyar Bus Stand",Coimbatore:"Gandhipuram Bus Stand",Trichy:"Chatram Bus Stand",Salem:"Salem New Bus Stand",Goa:"Panaji Kadamba Stand",Tirunelveli:"Tirunelveli New Bus Stand",Pondicherry:"Puducherry Bus Stand",Tirupati:"Tirupati Bus Station",Vellore:"Vellore New Bus Stand",Pune:"Swargate Bus Stand",Nagercoil:"Vadasery Bus Stand"};
var RATE={"Non-AC Seater":1.05,"AC Seater":1.45,"AC Sleeper":1.9,"Volvo Multi-Axle":2.1};
function calc(b,n){var base=b.fare*n,cg=Math.round(base*.025),fee=10+10*n;return{base:base,cg:cg,gst:cg*2,fee:fee,total:base+cg*2+fee}}
function refundOf(k){return Math.round((k.base+k.gst)*.9)}

var GEO={Chennai:[13.0827,80.2707],Bangalore:[12.9716,77.5946],Hyderabad:[17.385,78.4867],Mumbai:[19.076,72.8777],Kochi:[9.9312,76.2673],Madurai:[9.9252,78.1198],Coimbatore:[11.0168,76.9558],Trichy:[10.7905,78.7047],Salem:[11.6643,78.146],Goa:[15.4909,73.8278],Tirunelveli:[8.7139,77.7567],Pondicherry:[11.9416,79.8083],Tirupati:[13.6288,79.4192],Vellore:[12.9165,79.1325],Pune:[18.5204,73.8567],Nagercoil:[8.1833,77.4119]};
var lang="en",mode="m",cur="login";
function t(k){return L[lang][k]||L.en[k]||k}
var CITIES=["Chennai","Bangalore","Hyderabad","Mumbai","Kochi","Madurai","Coimbatore","Trichy","Salem","Goa","Tirunelveli","Pondicherry","Tirupati","Vellore","Pune","Nagercoil"];
var OPS=["S.E.T.C","TNSTC Volvo","Parveen Travels","KPN Travels","SRS Travels","Orange Tours","VRL Travels","Kallada Tours","SRM Travels","Jabbar Travels","National Travels","Sharma Travels"];
var TYPES=["AC Sleeper","AC Seater","Non-AC Seater","Volvo Multi-Axle"];
function rng(a){return function(){a|=0;a=a+0x6D2B79F5|0;var x=Math.imul(a^a>>>15,1|a);x=x+Math.imul(x^x>>>7,61|x)^x;return((x^x>>>14)>>>0)/4294967296}}
var ROUTE={};
function routeBuses(f,d){var r=CITIES.indexOf(f)*CITIES.length+CITIES.indexOf(d);if(ROUTE[r])return ROUTE[r];
 var G=rng(r*7919+13),dist=km(GEO[f],GEO[d]),l=[];
 function pk(a){return a[Math.floor(G()*a.length)]}
 for(var n=0;n<110;n++){var ty=pk(TYPES),spd=(ty==="Volvo Multi-Axle"?58:ty==="AC Sleeper"?50:ty==="AC Seater"?54:46)+G()*8;
  l.push({id:10000+r*1000+n,from:f,to:d,op:pk(OPS),type:ty,dep:Math.floor(G()*96)*15,dur:Math.max(1,Math.round(dist/spd*4)/4),dist:dist,fare:Math.max(100,Math.round(dist*RATE[ty]*(0.9+G()*0.25)/5)*5)})}
 l.sort(function(a,b){return a.dep-b.dep});return ROUTE[r]=l}

var KEY="busgo_v5",db=load(),me=null,S={},otpVal="",otpId="";if(!db.pf)db.pf={};
function load(){try{var s=localStorage.getItem(KEY);if(s)return JSON.parse(s)}catch(e){}return{bk:[],pf:{}}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(db))}catch(e){}}
function $(i){return document.getElementById(i)}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function p2(n){return(n<10?"0":"")+n}
function tf(m){m=((m%1440)+1440)%1440;var h=Math.floor(m/60);return p2(h%12||12)+":"+p2(m%60)+" "+(h<12?"AM":"PM")}
function dd(d){var a=d.split("-");return a[2]+"-"+a[1]+"-"+a[0]}
function msg(id,x,k){var e=$(id);if(e){e.textContent=x;e.className="msg "+(k||"")}}
function busOf(id){var r=Math.floor((id-10000)/1000),f=CITIES[Math.floor(r/CITIES.length)],d=CITIES[r%CITIES.length];return f&&d?routeBuses(f,d).find(function(b){return b.id===id}):null}
var HIST=[],HC=false;
function show(n,back){
 if(!back&&cur!==n){if(cur!=="login"&&n!=="tkv")HIST.push(cur);try{location.hash=n}catch(e){}}
 cur=n;clearInterval(TM);document.querySelectorAll(".scr").forEach(function(e){e.hidden=e.id!==n});
 document.querySelectorAll("#nav button").forEach(function(b){b.classList.toggle("on",b.dataset.v===n)});
 $("bk").hidden=!me||!HIST.length||n==="login";window.scrollTo(0,0)}

function taken(b,d){var m={},r=rng(b.id*997+parseInt(d.replace(/-/g,""),10)),n=8+Math.floor(r()*10);
 for(var i=0;i<n;i++)m[1+Math.floor(r()*40)]=r()<.5?"M":"F";
 db.bk.forEach(function(k){if(k.busId===b.id&&k.date===d&&!k.x)k.ps.forEach(function(p){m[p.seat]=p.g})});return m}

function applyLang(){
 document.documentElement.lang=lang;
 document.querySelectorAll("[data-i]").forEach(function(e){e.textContent=t(e.dataset.i)});
 document.querySelectorAll(".lang").forEach(function(e){e.value=lang});
 $("idLbl").textContent=t(mode==="m"?"mobLbl":"emailLbl");$("otpBtn").textContent=t($("otpBox").hidden?"sendOtp":"resend");
 if(me)buildNav();
 if(cur==="search")$("results").innerHTML=S.searched?"":'<div class="card mut">'+t("hint")+"</div>";
 if(cur==="search"&&S.searched)doSearch();
 if(cur==="seatv")renderSeats();if(cur==="payv")renderPay();if(cur==="mine")renderMine();if(cur==="admin")renderAdmin();if(cur==="profile")renderProfile();if(cur==="track")renderTrack();
 if(cur==="tkv"&&S.lastTk)showTicket(S.lastTk,true)}
function buildNav(){$("who").textContent=me.role==="a"?t("admin"):(db.pf[me.id]?db.pf[me.id].name:me.id);
 $("nav").innerHTML=me.role==="a"?'<button data-a="nav" data-v="admin">'+t("dash")+"</button>":'<button data-a="nav" data-v="search">'+t("nsearch")+'</button><button data-a="nav" data-v="mine">'+t("mine")+'</button><button data-a="nav" data-v="profile">'+t("profile")+"</button>";
 document.querySelectorAll("#nav button").forEach(function(b){b.classList.toggle("on",b.dataset.v===cur)})}
function setup(){
 var o=CITIES.map(function(c){return"<option>"+c+"</option>"}).join("");
 $("from").innerHTML=o;$("to").innerHTML=o;$("to").selectedIndex=1;
 $("date").value="2026-11-18";$("date").min="2026-11-17";
 try{lang=localStorage.getItem("busgo_lang")||"en"}catch(e){}if(!L[lang])lang="en";
 setMode("m");applyLang()}
function setMode(m){mode=m;var i=$("mob");i.value="";i.maxLength=m==="m"?10:60;i.inputMode=m==="m"?"numeric":"email";i.placeholder=m==="m"?"98XXXXXXXX":"name@example.com";
 $("otpBox").hidden=true;msg("lm","");$("idLbl").textContent=t(m==="m"?"mobLbl":"emailLbl");$("otpBtn").textContent=t("sendOtp")}
function enter(role,id){me={role:role,id:id};$("top").hidden=false;document.body.classList.add("app");buildNav();if(role==="p"&&!db.pf[id])go("profile");else go(role==="a"?"admin":"search")}
function go(v){if(v==="profile")renderProfile();if(v==="admin")renderAdmin();if(v==="mine")renderMine();if(v==="search"&&!S.searched)$("results").innerHTML='<div class="card mut">'+t("hint")+"</div>";show(v)}

function doSearch(){
 var f=$("from").value,d=$("to").value,dt=$("date").value;
 if(f===d)return $("results").innerHTML='<div class="card err">'+t("eSame")+"</div>";
 if(!dt)return $("results").innerHTML='<div class="card err">'+t("eDate")+"</div>";
 S.date=dt;S.searched=true;S.route=[f,d];renderResults()}
function renderResults(){
 var f=S.route[0],d=S.route[1],dt=S.date,ty=$("typef").value,so=$("sortb").value,all=routeBuses(f,d),
 l=all.filter(function(b){return!ty||b.type===ty}).sort(so==="price"?function(a,b){return a.fare-b.fare}:so==="dur"?function(a,b){return a.dur-b.dur}:function(a,b){return a.dep-b.dep});
 $("flt").hidden=false;
 $("results").innerHTML='<p class="mut">'+l.length+" "+t("buses")+": "+f+" → "+d+" · "+all[0].dist+" km · "+dd(dt)+"</p>"+l.map(function(b){
  var free=40-Object.keys(taken(b,dt)).length,ar=b.dep+Math.round(b.dur*60);
  return'<div class="card res"><div><div class="op">'+b.op+"</div><span class=tag>"+b.type+'</span><span class="mut">#'+b.id+'</span></div>'+
  '<div><span class="tm">'+tf(b.dep)+'</span> → <span class="tm">'+tf(ar)+"</span>"+(ar>=1440?' <span class="mut">+1</span>':"")+'<br><span class="mut">'+dh(b.dur)+"</span></div>"+
  '<div><div class="fare">₹'+b.fare+'</div><span class="mut">'+t("perSeat")+" · "+free+" "+t("left")+"</span></div>"+
  '<button class="btn" data-a="seats" data-v="'+b.id+'">'+t("viewSeats")+"</button></div>"}).join("")}

function openSeats(id){if(!db.pf[me.id]){go("profile");return}S.bus=busOf(id);S.sel={};renderSeats();show("seatv")}
function renderSeats(){
 var b=S.bus;if(!b)return;var tk=taken(b,S.date),h='<button class="btn sec" data-a="goback">'+t("back")+"</button>"+
 '<div class="card" style="margin-top:12px"><h2>'+b.from+" → "+b.to+'</h2><span class="mut">'+b.op+" · "+b.type+" · "+dd(S.date)+" · "+tf(b.dep)+'</span></div><div class="lay"><div class="card"><h3 style="text-align:center">'+t("select")+'</h3><div class="busbody">'+
 '<i class="wh" style="left:-14px;top:100px"></i><i class="wh" style="right:-14px;top:100px"></i><i class="wh" style="left:-14px;bottom:40px"></i><i class="wh" style="right:-14px;bottom:40px"></i>'+
 '<div class="drv"><svg width="26" height="26" viewBox="0 0 26 26" fill="none" stroke="#44505C" stroke-width="2.5"><circle cx="13" cy="13" r="10"/><circle cx="13" cy="13" r="2.5"/><path d="M13 15v8M3 12h7M16 12h7"/></svg>'+t("driver")+'</div><div class="seats">';
 for(var s=1;s<=40;s++){var c="",dis="";
  if(tk[s]){c=tk[s]==="M"?"bm":"bf";dis=" disabled"}
  if(S.sel[s])c=S.sel[s].g==="M"?"sm":"sf";
  h+='<button class="s '+c+'"'+dis+' data-a="seat" data-v="'+s+'" aria-label="Seat '+s+'">'+s+"</button>";
  if(s%4===2)h+="<span></span>"}
 h+='</div></div><div class="lg"><span><i></i>'+t("free")+'</span><span><i style="background:#2563EB"></i>'+t("selM")+'</span><span><i style="background:#DB2777"></i>'+t("selF")+'</span><span><i style="background:#9DBDF0"></i>'+t("bkM")+'</span><span><i style="background:#F4A9CB"></i>'+t("bkF")+'</span></div></div>'+
 '<div class="card"><h3>'+t("pd")+"</h3>";
 var ks=Object.keys(S.sel);
 if(!ks.length)h+='<p class="mut">'+t("seatHint")+"</p>";
 ks.forEach(function(k){var p=S.sel[k];
  h+='<div class="pr"><div class="sb" style="background:'+(p.g==="M"?"#2563EB":"#DB2777")+'">'+k+'</div><input data-f="name" data-s="'+k+'" placeholder="'+t("name")+'" value="'+esc(p.name)+'" maxlength="30"><input data-f="age" data-s="'+k+'" type="number" placeholder="'+t("age")+'" value="'+esc(p.age)+'" min="1" max="120">'+
  '<div class="gb"><button class="m'+(p.g==="M"?" on":"")+'" data-a="g" data-s="'+k+'" data-g="M">'+t("male")+'</button><button class="f'+(p.g==="F"?" on":"")+'" data-a="g" data-s="'+k+'" data-g="F">'+t("female")+"</button></div></div>"});
 h+='<div class="row" style="justify-content:space-between;margin:10px 0"><b>'+ks.length+" "+t("seatN")+'</b><b class="fare">₹'+ks.length*b.fare+'</b></div><p class="mut" style="margin:0 0 8px">'+t("plusTax")+'</p><button class="btn" style="width:100%" data-a="topay">'+t("proceed")+'</button><div class="msg err" id="sm"></div></div></div>';
 $("seatv").innerHTML=h}

function toPay(){
 var ks=Object.keys(S.sel);
 if(!ks.length)return msg("sm",t("eNone"),"err");
 for(var i=0;i<ks.length;i++){var p=S.sel[ks[i]],a=parseInt(p.age,10);
  if(!p.name.trim())return msg("sm",t("eName")+" "+ks[i],"err");
  if(!a||a<1||a>120)return msg("sm",t("eAge")+" "+ks[i],"err")}
 S.pay=S.pay||"upi";renderPay();show("payv")}
var PAY={upi:["UPI","UPI ID (name@upi)",/^[\w.\-]{2,}@\w{2,}$/,"📱"],card:["Debit / Credit card","Card number (16 digits)",/^\d{16}$/,"💳"],net:["Net banking","Bank name (example: SBI)",/^.{2,}$/,"🏦"],wal:["Wallet","Wallet mobile number",/^\d{10}$/,"👛"]};
function renderPay(){
 var b=S.bus,ks=Object.keys(S.sel),c=b?calc(b,ks.length):null,amt=c?c.total:0;if(!b)return;
 $("payv").innerHTML='<button class="btn sec" data-a="goback">'+t("back")+'</button><div class="lay" style="margin-top:12px"><div class="card"><h3>'+t("payOpt")+"</h3>"+
 Object.keys(PAY).map(function(k){return'<button class="po'+(S.pay===k?" on":"")+'" data-a="payopt" data-v="'+k+'"><span style="font-size:20px">'+PAY[k][3]+"</span><b>"+PAY[k][0]+"</b></button>"}).join("")+
 '<label>'+PAY[S.pay][1]+'<input id="pf" autocomplete="off"></label><div class="demo" style="margin-top:10px">'+t("demoPay")+"</div></div>"+
 '<div class="card"><h3>'+t("summary")+"</h3><p>"+b.from+" → "+b.to+'<br><span class="mut">'+b.op+" · "+dd(S.date)+" · "+tf(b.dep)+"</span></p>"+
 ks.map(function(k){var p=S.sel[k];return"<div>"+k+" · "+esc(p.name)+' <span class="chip '+(p.g==="M"?"cm":"cf")+'">'+t(p.g==="M"?"male":"female")+"</span></div>"}).join("")+
 '<hr>'+fareRows(c)+'<div class="row" style="justify-content:space-between"><b>'+t("total")+'</b><b class="fare">₹'+amt+'</b></div><button class="btn" style="width:100%;margin-top:10px" id="payBtn" data-a="confirm">'+t("pay")+" ₹"+amt+'</button><div class="msg err" id="pm" role="status"></div></div></div>'}

function confirmPay(){
 var v=$("pf").value.trim(),cfg=PAY[S.pay],val=S.pay==="card"?v.replace(/\s/g,""):v;
 if(!cfg[2].test(val))return msg("pm",t("ePay")+" "+cfg[1],"err");
 var b=S.bus,tk=taken(b,S.date),ks=Object.keys(S.sel),c=calc(b,ks.length);
 for(var i=0;i<ks.length;i++)if(tk[ks[i]])return msg("pm",t("eTaken")+" "+ks[i],"err");
 $("payBtn").disabled=true;$("payBtn").textContent=t("proc");
 setTimeout(function(){
  var last=1000;db.bk.forEach(function(k){var n=parseInt(k.id.slice(4),10);if(n>last)last=n});
  var k={id:"TKT-"+(last+1),uid:me.id,busId:b.id,date:S.date,pay:PAY[S.pay][0],base:c.base,gst:c.gst,fee:c.fee,amt:c.total,at:new Date().toLocaleString("en-IN"),
   ps:ks.map(function(s){var p=S.sel[s];return{seat:+s,name:p.name.trim(),age:+p.age,g:p.g}})};
  db.bk.push(k);save();S.sel={};S.lastTk=k;showTicket(k)},1200)}
function showTicket(k,keep){$("tkv").innerHTML='<div class="card ok"><b>'+t("ok")+"</b></div>"+tkHTML(k)+'<button class="btn" data-a="nav" data-v="search">'+t("another")+"</button>";drawQR();if(!keep){HIST=["search"];show("tkv")}}
function psHTML(k){return k.ps.map(function(p){return'<span class="chip '+(p.g==="M"?"cm":"cf")+'">'+p.seat+" · "+esc(p.name)+" ("+p.age+")</span>"}).join("")}
function age(d){var b=new Date(d),n=new Date(),a=n.getFullYear()-b.getFullYear(),m=n.getMonth()-b.getMonth();if(m<0||(m===0&&n.getDate()<b.getDate()))a--;return a}
function dh(d){var h=Math.floor(d),m=Math.round((d-h)*60);return h+"h "+p2(m)+"m"}
function addDay(iso,n){var a=iso.split("-"),d=new Date(+a[0],a[1]-1,+a[2]+n);return d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate())}
function wdate(iso){var a=iso.split("-");return new Date(+a[0],a[1]-1,+a[2]).toLocaleDateString("en-IN",{weekday:"short",day:"2-digit",month:"short",year:"numeric"})}
function fr(a,b){return'<div class="fr"><span>'+a+"</span><span>₹"+b+"</span></div>"}
function fareRows(c){return fr(t("baseFare"),c.base)+fr("CGST 2.5%",c.cg)+fr("SGST 2.5%",c.cg)+fr(t("conv"),c.fee)}
function tkHTML(k){
 var b=busOf(k.busId),ar=b.dep+Math.round(b.dur*60),p=db.pf[k.uid]||{},ph=p.mob?"+91 "+p.mob:k.uid,
 seats=k.ps.map(function(x){return x.seat}).join(", "),q=k.id+"|"+b.from+">"+b.to+"|"+k.date+"|Seats "+seats+"|"+k.ps[0].name,
 c={base:k.base,cg:k.gst/2,fee:k.fee},no=k.id.slice(4);
 return'<div class="tk2'+(k.x?" cx":"")+'"><div class="hd"><svg class="lg2"><use href="#logo"/></svg><b>BusGo</b><span>Travel safe. Travel smart.</span></div><div class="bd">'+
 '<div class="tt"><h3>'+t("tkTitle")+"</h3><span>"+t("bookId")+": <b>"+k.id+"</b></span></div>"+
 '<div class="jr"><div><div class="city">'+b.from+'</div><div class="stand">'+(STAND[b.from]||"")+'</div><div class="when">'+wdate(k.date)+"<br>"+tf(b.dep)+"</div></div>"+
 '<div class="mid">🚌<i></i>'+dh(b.dur)+'</div><div><div class="city">'+b.to+'</div><div class="stand">'+(STAND[b.to]||"")+'</div><div class="when">'+wdate(addDay(k.date,Math.floor(ar/1440)))+"<br>"+tf(ar)+"</div></div>"+
 '<div class="qr" data-q="'+esc(q)+'"><div class="qb"></div>Scan at boarding</div></div>'+
 '<div class="strip"><div><span>'+t("operator")+"</span><b>"+b.op+"</b></div><div><span>"+t("type")+"</span><b>"+b.type+"</b></div><div><span>"+t("seatNo")+"</span><b>"+seats+"</b></div><div><span>"+t("amount")+"</span><b>₹"+k.amt+"</b></div></div>"+
 '<div class="pas"><div><span class="mut">'+t("pass2")+"</span><br>"+psHTML(k)+'</div><div><span class="mut">'+t("mobileNo")+"</span><br><b>"+esc(ph)+'</b></div><span class="badge'+(k.x?" x":"")+'">'+t(k.x?"cancelled":"confirmed")+"</span></div>"+
 '<div style="margin-top:14px"><b>'+t("fareDet")+"</b>"+fareRows(c)+fr(t("payL"),k.pay)+'<div class="fr" style="color:var(--ink);font-weight:700"><span>'+t("total")+"</span><span>₹"+k.amt+"</span></div></div>"+
 '<details class="inv"><summary>'+t("taxInv")+"</summary><p>"+t("invNo")+": INV-"+no+" · "+k.at+"<br>Supplier: "+b.op+" · GSTIN: 33AAAAA0000A1Z5 · SAC: 996421<br>"+esc(k.ps[0].name)+" · "+esc(ph)+"</p>"+
 "<table><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th></tr><tr><td>Bus fare "+b.from+" to "+b.to+"</td><td>"+k.ps.length+"</td><td>₹"+b.fare+"</td><td>₹"+k.base+"</td></tr><tr><td>CGST @2.5%</td><td></td><td></td><td>₹"+c.cg+"</td></tr><tr><td>SGST @2.5%</td><td></td><td></td><td>₹"+c.cg+"</td></tr><tr><td>"+t("conv")+"</td><td>1</td><td>₹"+k.fee+"</td><td>₹"+k.fee+"</td></tr><tr><td colspan=\"3\"><b>"+t("total")+"</b></td><td><b>₹"+k.amt+'</b></td></tr></table><p class="mut">'+t("sample")+"</p></details>"+
 '<div class="note">'+t("reach")+" "+t("happy")+"</div></div>"+acts(k)+"</div>"}
function acts(k){return'<div class="row noprint" style="padding:0 16px 14px">'+(k.x?'<b class="err">'+t("cancelled")+" · "+t("refund")+" ₹"+k.ref+"</b>":'<button class="btn" data-a="track" data-v="'+k.id+'">'+t("track")+'</button><button class="btn sec" data-a="print">'+t("printT")+'</button><button class="btn sec" data-a="cancel" data-v="'+k.id+'">'+t("cancelTkt")+"</button>")+"</div>"}
function renderMine(){var l=db.bk.filter(function(k){return k.uid===me.id}).slice().reverse();
 $("mine").innerHTML="<h2>"+t("mine")+"</h2>"+(l.length?l.map(tkHTML).join(""):'<div class="card mut">'+t("empty")+"</div>");drawQR()}
function drawQR(){document.querySelectorAll(".qr").forEach(function(e){var h=e.querySelector(".qb");if(!h||h.firstChild)return;
 try{if(typeof QRCode==="undefined")throw 0;new QRCode(h,{text:e.dataset.q,width:100,height:100,correctLevel:QRCode.CorrectLevel.M})}catch(x){h.innerHTML=fakeQR(e.dataset.q)}})}
/* fallback pattern used only if the QR library cannot load */
function fakeQR(s){var h=0,i,r,c,o="",m=4;for(i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;var g=rng(h);
 function fp(x,y){return'<rect x="'+x*m+'" y="'+y*m+'" width="28" height="28" fill="#000"/><rect x="'+(x*m+4)+'" y="'+(y*m+4)+'" width="20" height="20" fill="#fff"/><rect x="'+(x*m+8)+'" y="'+(y*m+8)+'" width="12" height="12" fill="#000"/>'}
 for(r=0;r<21;r++)for(c=0;c<21;c++){if((r<8&&c<8)||(r<8&&c>12)||(r>12&&c<8))continue;if(g()<.5)o+='<rect x="'+c*m+'" y="'+r*m+'" width="'+m+'" height="'+m+'" fill="#000"/>'}
 return'<svg width="100" height="100" viewBox="0 0 84 84" style="background:#fff;display:block;margin:0 auto 4px">'+o+fp(0,0)+fp(14,0)+fp(0,14)+"</svg>"}

function renderScreen(p){if(p==="profile")renderProfile();else if(p==="admin")renderAdmin();else if(p==="mine")renderMine();
 else if(p==="search"&&S.searched)renderResults();else if(p==="seatv"&&S.bus)renderSeats();else if(p==="payv"&&S.bus)renderPay();else if(p==="track"&&S.trk)renderTrack()}
function goBack(){var p=HIST.pop()||(me&&me.role==="a"?"admin":"search");renderScreen(p);show(p,true);if(p==="track"&&S.trk)TM=setInterval(tick,1000)}
function backBtn(){HC=false;history.back();setTimeout(function(){if(!HC)goBack()},250)}
window.addEventListener("hashchange",function(){HC=true;if(!me)return;if(location.hash.slice(1)===cur)return;goBack()});

function renderAdmin(){
 var seats=0,rev=0,cx=0;db.bk.forEach(function(k){if(k.x)cx++;else{seats+=k.ps.length;rev+=k.amt}});
 $("admin").innerHTML="<h2>"+t("dash")+'</h2><div class="stats"><div class="card"><span class="mut">'+t("active")+"</span><b>"+(db.bk.length-cx)+'</b></div><div class="card"><span class="mut">'+t("sold")+"</span><b>"+seats+'</b></div><div class="card"><span class="mut">'+t("rev")+"</span><b>₹"+rev+'</b></div><div class="card"><span class="mut">'+t("cancelled")+"</span><b>"+cx+'</b></div></div>'+
 '<div class="card"><div class="row" style="margin-bottom:10px"><label>'+t("filter")+'<input id="aq"></label></div><div class="tbl" id="atb"></div></div>';adminRows("")}
function adminRows(q){q=q.toLowerCase();
 var l=db.bk.filter(function(k){var p=db.pf[k.uid]||{};return!q||(k.id+k.uid+(p.name||"")+k.ps.map(function(x){return x.name}).join(" ")).toLowerCase().indexOf(q)>-1}).slice().reverse();
 $("atb").innerHTML=l.length?"<table><tr><th>"+t("ticket")+"</th><th>"+t("by")+"</th><th>"+t("rb")+"</th><th>"+t("td")+"</th><th>"+t("pass2")+"</th><th>"+t("pm")+"</th><th>"+t("amount")+"</th><th>"+t("status")+"</th></tr>"+l.map(function(k){var b=busOf(k.busId),p=db.pf[k.uid]||{};
  return"<tr><td><b>"+k.id+'</b><br><span class="mut">'+k.at+"</span></td><td><b>"+esc(p.name||"-")+"</b><br>"+esc(k.uid)+(p.age?'<br><span class="mut">'+t("ageL")+" "+p.age+" · "+(p.g||"")+"</span>":"")+"</td><td>"+b.from+" → "+b.to+'<br><span class="mut">#'+b.id+" · "+b.op+"</span></td><td>"+dd(k.date)+"</td><td>"+psHTML(k)+"</td><td>"+k.pay+"</td><td>₹"+k.amt+"</td><td>"+
  (k.x?'<span class="err">'+t("cancelled")+'</span><br><span class="mut">'+t("refund")+" ₹"+k.ref+"</span>":'<span class="ok">'+t("confirmed")+'</span><br><button class="lk b" data-a="track" data-v="'+k.id+'">'+t("track")+'</button><button class="lk" data-a="cancel" data-v="'+k.id+'">'+t("cancelTkt")+"</button>")+"</td></tr>"}).join("")+"</table>":'<p class="mut">'+t("empty")+"</p>"}

function defP(){var p=db.pf[me.id];return p&&!Object.keys(S.sel).length?{name:p.name,age:String(p.age),g:p.g==="F"?"F":"M"}:{name:"",age:"",g:"M"}}
function renderProfile(){var p=db.pf[me.id]||{},im=me.id.indexOf("+91")===0,mv=p.mob||(im?me.id.slice(4):""),ev=p.email||(im?"":me.id);
 $("profile").innerHTML='<div class="card"><h2>'+t("profile")+'</h2><p class="mut">'+t("profileHint")+'</p><div class="row">'+
 '<label>'+t("fullName")+'<input id="pfN" maxlength="40" value="'+esc(p.name||"")+'"></label>'+
 '<label>'+t("dob")+'<input id="pfD" type="date" min="1900-01-01" max="2026-11-17" value="'+(p.dob||"")+'"></label>'+
 '<label>'+t("ageL")+'<b id="pfA" style="font-size:18px;color:var(--ink);padding:8px 0">'+(p.age||"-")+"</b></label></div>"+
 '<div class="row" style="margin-top:10px"><label>'+t("gender")+'<select id="pfG"><option value="">--</option><option value="M"'+(p.g==="M"?" selected":"")+">"+t("male")+'</option><option value="F"'+(p.g==="F"?" selected":"")+">"+t("female")+'</option><option value="O"'+(p.g==="O"?" selected":"")+">"+t("other")+"</option></select></label>"+
 '<label>'+t("mobileNo")+'<input id="pfM" maxlength="10" inputmode="numeric" value="'+esc(mv)+'"'+(im?" readonly":"")+"></label>"+
 '<label>'+t("emailAd")+'<input id="pfE" maxlength="60" value="'+esc(ev)+'"'+(im?"":" readonly")+"></label>"+
 '<label>'+t("city")+'<input id="pfC" maxlength="30" value="'+esc(p.city||"")+'"></label></div><button class="btn" style="margin-top:14px" data-a="saveprofile">'+t("saveP")+'</button><div class="msg" id="pfMsg" role="status"></div></div>'}
function saveProfile(){
 var n=$("pfN").value.trim(),d=$("pfD").value,g=$("pfG").value,m=$("pfM").value.trim(),e=$("pfE").value.trim(),a=d?age(d):0,first=!db.pf[me.id];
 if(n.length<2)return msg("pfMsg",t("eProfName"),"err");
 if(!d||a<1||a>120)return msg("pfMsg",t("eDob"),"err");
 if(!g)return msg("pfMsg",t("eGender"),"err");
 if(m&&!/^[6-9]\d{9}$/.test(m))return msg("pfMsg",t("eMob"),"err");
 if(e&&!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e))return msg("pfMsg",t("eEmail"),"err");
 db.pf[me.id]={name:n,dob:d,age:a,g:g,mob:m,email:e,city:$("pfC").value.trim()};save();buildNav();
 msg("pfMsg",t("saved"),"ok");if(first)go("search")}

function modal(h){$("modal").innerHTML='<div class="ov"><div class="card" style="max-width:400px;width:100%;margin:0">'+h+"</div></div>";$("modal").hidden=false}
function openCancel(id){var k=db.bk.find(function(x){return x.id===id});if(!k||k.x)return;
 S.cx={id:id,otp:String(100000+Math.floor(Math.random()*900000))};var ad=me.role==="a";
 modal("<h3>"+t("cancelTkt")+": "+id+'</h3><p class="mut">'+t(ad?"verifyCxA":"verifyCx")+"</p>"+(ad?'<label>'+t("pass")+'<input id="cxv" type="password"></label>':'<div class="demo">'+t("demoOtp")+"<br><b>"+S.cx.otp+'</b></div><label>'+t("otpLbl")+'<input id="cxv" inputmode="numeric" maxlength="6"></label>')+
 '<p class="mut">'+t("refundNote")+" ₹"+refundOf(k)+'</p><div class="msg err" id="cxm" role="status"></div><div class="row"><button class="btn" data-a="cxok">'+t("confirmCx")+'</button><button class="btn sec" data-a="mclose">'+t("keep")+"</button></div>")}
function doCancel(){
 var v=$("cxv").value.trim(),k=db.bk.find(function(x){return x.id===S.cx.id});
 if(me.role==="a"?v!=="admin123":v!==S.cx.otp)return msg("cxm",t("eVerify"),"err");
 k.x=true;k.ref=refundOf(k);k.xat=new Date().toLocaleString("en-IN");save();$("modal").hidden=true;
 if(cur==="mine")renderMine();else if(cur==="admin")renderAdmin();else if(cur==="tkv")showTicket(k,true)}

function km(a,b){var r=Math.PI/180,x=(b[0]-a[0])*r,y=(b[1]-a[1])*r,h=Math.sin(x/2)*Math.sin(x/2)+Math.cos(a[0]*r)*Math.cos(b[0]*r)*Math.sin(y/2)*Math.sin(y/2);return Math.round(12742*Math.asin(Math.sqrt(h))*1.12)}
function xy(g){return[(g[1]-72)/9*270+15,(20-g[0])/12*280+15]}
function prog(k,b){if(S.sim&&S.sim.id===k.id)return Math.min(1,(Date.now()-S.sim.t0)/40000);
 var p=k.date.split("-"),st=new Date(+p[0],p[1]-1,+p[2],0,0).getTime()+b.dep*60000;return Math.max(0,Math.min(1,(Date.now()-st)/(b.dur*3600000)))}
function openTrack(id){var k=db.bk.find(function(x){return x.id===id});if(!k)return;S.trk=k;S.sim=null;renderTrack();show("track");TM=setInterval(tick,1000);tick()}
function renderTrack(){var k=S.trk,b=busOf(k.busId),a=xy(GEO[b.from]),z=xy(GEO[b.to]);GMT=0;
 var pts=CITIES.map(function(c){var q=xy(GEO[c]),hl=c===b.from||c===b.to;return'<circle cx="'+q[0]+'" cy="'+q[1]+'" r="'+(hl?5:3)+'" fill="'+(hl?"#C8102E":"#7A8794")+'"/><text x="'+(q[0]+6)+'" y="'+(q[1]+3)+'" font-size="9" fill="#33414F">'+c+"</text>"}).join("");
 $("track").innerHTML='<button class="btn sec" data-a="goback">'+t("back")+'</button><div class="card" style="margin-top:12px"><h2>'+t("trackTitle")+": "+b.from+" → "+b.to+'</h2><span class="mut">'+k.id+" · "+b.op+" · "+dd(k.date)+'</span></div><div class="lay"><div class="card"><svg viewBox="0 0 300 310" style="width:340px;max-width:100%;background:#E8F1F6;border-radius:6px"><line x1="'+a[0]+'" y1="'+a[1]+'" x2="'+z[0]+'" y2="'+z[1]+'" stroke="#C8102E" stroke-width="3" stroke-dasharray="6 4"/>'+pts+'<circle id="bd" r="8" cx="'+a[0]+'" cy="'+a[1]+'" fill="#C8102E" stroke="#fff" stroke-width="3"/></svg></div>'+
 '<div class="card"><div id="ti"></div><div class="row" style="margin:12px 0"><button class="btn" data-a="sim">'+t("simulate")+'</button><a class="btn sec" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&amp;origin='+b.from+"&amp;destination="+b.to+'">'+t("openMaps")+'</a></div><iframe id="gm" title="Google Map" style="width:100%;height:260px;border:0;border-radius:6px"></iframe><div id="gmf" class="mut" hidden>'+t("gmFail")+"</div></div></div>"}
function tick(){var k=S.trk;if(!k||!$("bd"))return;var b=busOf(k.busId),A=GEO[b.from],B=GEO[b.to],d=km(A,B),p=prog(k,b),
 lat=A[0]+(B[0]-A[0])*p,lng=A[1]+(B[1]-A[1])*p,q=xy([lat,lng]),sim=S.sim&&S.sim.id===k.id,
 st=p<=0?t("notStarted"):p>=1?t("arrived"):t("inTransit"),sp=p>0&&p<1?Math.round(d/b.dur+Math.sin(Date.now()/2500)*5):0;
 $("bd").setAttribute("cx",q[0]);$("bd").setAttribute("cy",q[1]);
 $("ti").innerHTML="<h3>"+st+(sim?' <span class="mut">('+t("simOn")+")</span>":"")+'</h3><div class="pbar"><div style="width:'+Math.round(p*100)+'%"></div></div><div class="kv"><div><span>'+t("distance")+"</span><b>"+d+' km</b></div><div><span>'+t("covered")+"</span><b>"+Math.round(d*p)+' km</b></div><div><span>'+t("remaining")+"</span><b>"+Math.round(d*(1-p))+' km</b></div><div><span>'+t("speed")+"</span><b>"+sp+' km/h</b></div><div><span>'+t("dep")+"</span><b>"+tf(b.dep)+"</b></div><div><span>"+t("eta")+"</span><b>"+tf(b.dep+b.dur*60)+"</b></div></div>";
 if(Date.now()-GMT>12000){GMT=Date.now();var u="https://maps.google.com/maps?q="+lat.toFixed(4)+","+lng.toFixed(4)+"&z=8&output=embed";if($("gm").getAttribute("src")!==u)$("gm").src=u}}
document.addEventListener("securitypolicyviolation",function(){var f=$("gm");if(f&&!f.hidden){f.hidden=true;$("gmf").hidden=false}});

document.addEventListener("click",function(e){
 var el=e.target.closest("[data-a]");if(!el)return;var a=el.dataset.a,v=el.dataset.v;
 if(a==="tab"){$("pLogin").hidden=v==="a";$("aLogin").hidden=v!=="a";if(v!=="a")setMode(v);else msg("lm","");document.querySelectorAll(".tabs button").forEach(function(b){b.classList.toggle("on",b===el)})}
 else if(a==="sendotp"){var id=$("mob").value.trim();
  if(mode==="m"&&!/^[6-9]\d{9}$/.test(id))return msg("lm",t("eMob"),"err");
  if(mode==="e"&&!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(id))return msg("lm",t("eEmail"),"err");
  otpId=mode==="m"?"+91 "+id:id.toLowerCase();otpVal=String(100000+Math.floor(Math.random()*900000));$("otpBox").hidden=false;$("otpBtn").textContent=t("resend");
  $("demo").innerHTML=t("demoOtp")+"<br><b>"+otpVal+"</b>";msg("lm",t("sent")+" "+otpId,"ok")}
 else if(a==="verify"){if(!otpVal||$("otp").value.trim()!==otpVal)return msg("lm",t("eOtp"),"err");otpVal="";enter("p",otpId)}
 else if(a==="admin"){if($("au").value.trim()==="admin"&&$("ap").value==="admin123")enter("a","admin");else msg("lm",t("eAdmin"),"err")}
 else if(a==="logout"){me=null;S={};HIST=[];$("modal").hidden=true;$("top").hidden=true;document.body.classList.remove("app");$("otp").value="";$("ap").value="";setMode(mode);show("login")}
 else if(a==="nav")go(v);
 else if(a==="swap"){var f=$("from").value;$("from").value=$("to").value;$("to").value=f}
 else if(a==="search")doSearch();
 else if(a==="seats")openSeats(+v);
 else if(a==="seat"){var s=el.dataset.v;if(S.sel[s])delete S.sel[s];else{if(Object.keys(S.sel).length>=6)return msg("sm",t("eMax"),"err");S.sel[s]=defP()}renderSeats()}
 else if(a==="g"){S.sel[el.dataset.s].g=el.dataset.g;renderSeats()}
 else if(a==="topay")toPay();
 else if(a==="back"){renderSeats();show("seatv")}
 else if(a==="payopt"){S.pay=v;renderPay()}
 else if(a==="confirm")confirmPay();
 else if(a==="saveprofile")saveProfile();
 else if(a==="track")openTrack(v);
 else if(a==="sim"){S.sim={id:S.trk.id,t0:Date.now()}}
 else if(a==="cancel")openCancel(v);
 else if(a==="cxok")doCancel();
 else if(a==="mclose")$("modal").hidden=true;
 else if(a==="goback")backBtn();
 else if(a==="print")window.print();
});
document.addEventListener("input",function(e){var f=e.target.dataset.f;if(f&&S.sel)S.sel[e.target.dataset.s][f]=e.target.value;if(e.target.id==="aq")adminRows(e.target.value);if(e.target.id==="pfD"&&e.target.value)$("pfA").textContent=age(e.target.value)});
document.addEventListener("change",function(e){if(e.target.id==="sortb"||e.target.id==="typef"){renderResults();return}if(e.target.classList.contains("lang")){lang=e.target.value;try{localStorage.setItem("busgo_lang",lang)}catch(x){}applyLang()}});
setup();
