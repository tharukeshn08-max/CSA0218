/* BUS RESERVATION AND TICKETING SYSTEM  (C capstone)
   Compile: gcc bus_reservation.c -o bus
   Run    : ./bus   (Windows: bus.exe)
   Files  : buses.dat (bus + seat status), tickets.dat (bookings) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_BUS   3
#define SEATS     40
#define BUSFILE   "buses.dat"
#define TKTFILE   "tickets.dat"

struct Bus {
    int   busNo;
    char  from[20], to[20], time[20], date[20];
    float fare;
    int   seat[SEATS + 1];          /* 0 = free, 1 = booked (index 1..40) */
};

struct Ticket {
    int   ticketNo;
    char  name[30];
    int   age;
    int   busNo;
    int   seatNo;
    float fare;
};

struct Bus buses[MAX_BUS];

void defaultBuses(void) {
    struct Bus d[MAX_BUS] = {
        {101, "Chennai", "Bangalore", "10:30 PM", "20-12-2026", 650},
        {102, "Chennai", "Madurai",   "09:00 PM", "20-12-2026", 720},
        {103, "Chennai", "Coimbatore","08:15 PM", "21-12-2026", 800}
    };
    memcpy(buses, d, sizeof(d));
}

void saveBuses(void) {
    FILE *fp = fopen(BUSFILE, "wb");
    if (!fp) { printf("Cannot save bus file!\n"); return; }
    fwrite(buses, sizeof(struct Bus), MAX_BUS, fp);
    fclose(fp);
}

void loadBuses(void) {
    FILE *fp = fopen(BUSFILE, "rb");
    if (fp && fread(buses, sizeof(struct Bus), MAX_BUS, fp) == MAX_BUS) {
        fclose(fp);
    } else {
        if (fp) fclose(fp);
        defaultBuses();
        saveBuses();
    }
}

int findBus(int no) {
    for (int i = 0; i < MAX_BUS; i++)
        if (buses[i].busNo == no) return i;
    return -1;
}

int nextTicketNo(void) {
    struct Ticket t; int last = 1000;
    FILE *fp = fopen(TKTFILE, "rb");
    if (!fp) return 1001;
    while (fread(&t, sizeof(t), 1, fp) == 1)
        if (t.ticketNo > last) last = t.ticketNo;
    fclose(fp);
    return last + 1;
}

void viewBuses(void) {
    printf("\n%-6s %-12s %-12s %-12s %-10s %-6s %-5s\n",
           "BusNo", "From", "To", "Date", "Time", "Fare", "Free");
    for (int i = 0; i < MAX_BUS; i++) {
        int free = 0;
        for (int s = 1; s <= SEATS; s++) if (!buses[i].seat[s]) free++;
        printf("%-6d %-12s %-12s %-12s %-10s %-6.0f %-5d\n",
               buses[i].busNo, buses[i].from, buses[i].to,
               buses[i].date, buses[i].time, buses[i].fare, free);
    }
}

void showSeats(int b) {
    printf("\nSeat map for bus %d  ([ ] free, [X] booked)\n", buses[b].busNo);
    for (int s = 1; s <= SEATS; s++) {
        printf(buses[b].seat[s] ? "[XX] " : "[%02d] ", s);
        if (s % 4 == 0) printf("\n");
    }
}

void printTicket(struct Ticket t, struct Bus b) {
    printf("\n==============================\n");
    printf("          BUS TICKET\n");
    printf("==============================\n");
    printf(" Ticket No : TKT-%d\n", t.ticketNo);
    printf(" Passenger : %s\n", t.name);
    printf(" Age       : %d\n", t.age);
    printf(" Bus No    : %d\n", t.busNo);
    printf(" Route     : %s -> %s\n", b.from, b.to);
    printf(" Date/Time : %s, %s\n", b.date, b.time);
    printf(" Seat No   : %d\n", t.seatNo);
    printf(" Fare      : Rs. %.0f\n", t.fare);
    printf("==============================\n");
}

void bookTicket(void) {
    struct Ticket t; int no, b;
    viewBuses();
    printf("\nEnter bus number: ");
    if (scanf("%d", &no) != 1) { while (getchar() != '\n'); printf("Invalid input.\n"); return; }
    b = findBus(no);
    if (b < 0) { printf("Bus not found.\n"); return; }
    showSeats(b);
    printf("\nEnter seat number (1-%d): ", SEATS);
    if (scanf("%d", &t.seatNo) != 1) { while (getchar() != '\n'); printf("Invalid input.\n"); return; }
    if (t.seatNo < 1 || t.seatNo > SEATS) { printf("Invalid seat number.\n"); return; }
    if (buses[b].seat[t.seatNo]) { printf("Seat already booked. Choose another seat.\n"); return; }
    getchar();
    printf("Passenger name: ");
    fgets(t.name, sizeof(t.name), stdin);
    t.name[strcspn(t.name, "\n")] = '\0';
    printf("Age: ");
    if (scanf("%d", &t.age) != 1 || t.age < 1 || t.age > 120) {
        while (getchar() != '\n') { }
        printf("Invalid age.\n");
        return;
    }
    t.ticketNo = nextTicketNo();
    t.busNo = no;
    t.fare = buses[b].fare;
    buses[b].seat[t.seatNo] = 1;

    FILE *fp = fopen(TKTFILE, "ab");
    if (!fp) { printf("Cannot open ticket file!\n"); buses[b].seat[t.seatNo] = 0; return; }
    fwrite(&t, sizeof(t), 1, fp);
    fclose(fp);
    saveBuses();
    printTicket(t, buses[b]);
}

void cancelTicket(void) {
    struct Ticket t; int no, found = 0;
    printf("Enter ticket number (e.g. 1001): ");
    if (scanf("%d", &no) != 1) { while (getchar() != '\n'); printf("Invalid input.\n"); return; }
    FILE *fp = fopen(TKTFILE, "rb");
    FILE *tmp = fopen("temp.dat", "wb");
    if (!fp || !tmp) { printf("Ticket not found.\n"); if (fp) fclose(fp); if (tmp) fclose(tmp); return; }
    while (fread(&t, sizeof(t), 1, fp) == 1) {
        if (t.ticketNo == no) {
            found = 1;
            int b = findBus(t.busNo);
            if (b >= 0) buses[b].seat[t.seatNo] = 0;
            printf("Ticket TKT-%d cancelled. Refund: Rs. %.0f\n", t.ticketNo, t.fare);
        } else fwrite(&t, sizeof(t), 1, tmp);
    }
    fclose(fp); fclose(tmp);
    remove(TKTFILE); rename("temp.dat", TKTFILE);
    if (found) saveBuses(); else printf("Ticket not found.\n");
}

void viewBookings(void) {
    struct Ticket t; int n = 0;
    FILE *fp = fopen(TKTFILE, "rb");
    if (!fp) { printf("No bookings yet.\n"); return; }
    printf("\n%-10s %-20s %-4s %-6s %-5s %-6s\n", "Ticket", "Name", "Age", "Bus", "Seat", "Fare");
    while (fread(&t, sizeof(t), 1, fp) == 1) {
        printf("TKT-%-6d %-20s %-4d %-6d %-5d %-6.0f\n",
               t.ticketNo, t.name, t.age, t.busNo, t.seatNo, t.fare);
        n++;
    }
    fclose(fp);
    if (!n) printf("No bookings yet.\n");
}

int main(void) {
    int choice;
    loadBuses();
    do {
        printf("\n===== BUS RESERVATION SYSTEM =====\n");
        printf("1. View Buses\n2. Book Ticket\n3. Cancel Ticket\n");
        printf("4. View Bookings\n5. Exit\nEnter choice: ");
        if (scanf("%d", &choice) != 1) { while (getchar() != '\n'); choice = 0; }
        switch (choice) {
            case 1: viewBuses();    break;
            case 2: bookTicket();   break;
            case 3: cancelTicket(); break;
            case 4: viewBookings(); break;
            case 5: printf("Thank you!\n"); break;
            default: printf("Invalid choice.\n");
        }
    } while (choice != 5);
    return 0;
}
